#ToAddData
# Part 12 Income and Expenses
When you die, income from many sources will diminish or cease, but expenses won't. Your heirs should have easy access to your sources of income and regular expenses. Often, all that is needed is the most recent copy of your bank statement or even the register of your check book.  If all of this information is in your computer, jot down how it can be accessed (See Passwords and Pins).

## Income
**Income** for which the estate may receive:

**Income Source/Date Rec'd/(Period: Monthly-Quarterly-Yearly)=Amount
How Received**

(**List the income data from all sources**)

## Expenses
**Expenses** for which the estate may be liable - credit cards, mortgages, condo fees, HOA fees, taxes, utilities:

**Expense Source/Date Due/(Period: Monthly-Quarterly-Yearly) = Amount
How Paid**

**(List the expense data due to all sources)**



