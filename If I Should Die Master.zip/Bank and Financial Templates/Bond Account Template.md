#Template 
# Bonds or Bond Accounts
**U.S. Government Savings Bonds:**
    Location:  (**Location**)
    Number:  (**Number**)
    Denominations:  (**Denominations**)
    List of:
        (**Location and Serial Numbers**)
    Payable on Death To:
         (**Name**)
         (**Address**)
         (**Phone**)
         (**email**)

**Corporate or Municipal or Other Bond Holdings:**
     Account:  (**Account**)
     Identification Number:  (**Identification Number**)
     Location of Records:  (**Hard copy, computer file, etc.**)
     Broker or Contact Information:
         (**Name**)
         (**Address**)
         (**Phone**)
         (**email**)
 
