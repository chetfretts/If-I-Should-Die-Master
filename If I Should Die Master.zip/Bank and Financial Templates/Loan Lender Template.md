#Template
# Loan I am the Lender:
You are the Lender:
    Debtor's Information:
        (**Name**)
         (**Address**)
         (**Phone**)
         (**email**)   
    Original Loan Amount:  (**Amount**)
    Original Date of Loan:  (**Date**)
    Original Location of Loan:  (**Location**)
    Type of Loan (Promissory Note or Other):  (**Type**)
        If not a promissory note, what if any record was made of this transaction and what is it's location:
            (**Record of loan and location)
    
    
    
