#Template 
# Loans I Have Guaranteed:
Creditor:
    Loan guaranteed from whom:
        (**Name**)
         (**Address**)
         (**Phone**)
         (**email**)   
    Amount guaranteed:  (**Amount**)
    Contact or Notification:
        (**Contract or notification information**)