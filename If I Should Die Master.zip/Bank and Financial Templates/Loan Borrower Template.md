#Template 
# Loan Borrower 
Document the details of loans where you are the debtor or borrower or mortgagee.

You are the Borrower:
    Creditor's:
        (**Name or Names**)
         (**Address**)
         (**Phone**)
         (**email**)
    Type or transaction (Mortgage, Car, Boat, Home Equity, etc.):  (**Type**)
    Original Loan Amount:  (**Amount**)
    Original Date of Loan:  (**Date**)
    Location of Loan contract:  (**Location**)
        If none exists, what if any record was made of this transaction and what is it's location:
            (**Type of record and location**)
    