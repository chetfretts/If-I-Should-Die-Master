#Template 
# Investment Account
Investment Accounts can include Stock Accounts, Stocks, Mutual Funds,  IRA, SEP, Variable annuities, etc.

Are these records computerized, make sure that the executer knows how to access the files:  (**document if needed**)

Type of Account:  (**Type**)
    Account Identifier:  (**Identifier**)
    Brokerage or Company holding account:  (**Brokerage or Company**)
    Contact or Broker:
        (**Name**)
        (**Address**)
        (**email**)
        (**Phone**)

Note: For paper records, attach copies of your periodic statements.
    