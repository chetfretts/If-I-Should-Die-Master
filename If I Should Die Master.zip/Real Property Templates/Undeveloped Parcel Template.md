#Template 
# Undeveloped Parcel Template
These undeveloped parcels include parcels such as acreage, building lots, farms, burial plots, etc.

Are these records computerized, make sure that the executer knows how to access the files:  (**document if needed**)

Address or legal description of parcel:
    (**details**)

Name and location of proof of ownership (deed, etc.):
    (**details**)

Deed recorded at:
    (**Location**)

Nature of ownership (proprietor, joint tenancy, tenancy by entirely, etc.):
    (**specify**)

Is this property encumbered by mortgage?
    (**Specify the details**)

Is property leased, loaned, or otherwise encumbered by a tenant and if so, what is the name and address of the tenant?
    (**Specify the details**)

Nature of tenancy and where Is the supporting documentation located?
    (**Specify the details**)

Estimated value of property:
    (**Specify the details**)

Estimated equity value:
    (**Specify the details**)

What is the estimate based up? (appraisal, tax assessment, etc.):
    (**Specify the details**)

Date of document:
    (**Date**)

Amount of annual taxes paid:
    (**Amount**)

To what entity are taxes paid?
    (**Specify name, address, phone**)

Is this property serviced by utilities? (electricity, water, sewerage, etc.)
    (**Specify the details**)
  