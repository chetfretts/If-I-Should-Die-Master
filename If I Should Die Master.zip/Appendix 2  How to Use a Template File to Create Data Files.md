#ToWrite 
# Appendix 2 How to Add Data Files
The following example shows how I add a checking account file at USA Bank to my Part 7 Bank Accounts. 
    1) Click Part 7 Bank Accounts
    2) Click the Bank Account Template
    3) Copy the Bank Account Template file
    4) Go back to Part 7
    5) Add a link file for the USA Bank Checking
    6) Click the USA Bank Account file
    7) Paste the template information into the USA Bank Account file
    8) Add your data to that file
    9) Repeat the above steps for each account

Here are some more details on how to achieve the above actions.
    1) Go to the Part 7, click START HERE, click Part 7 Bank Accounts and Financial Holdings
    2) Add the checking account as a link as a file by typing USA Bank Checking using two open square brackets before the USA and two close square brackets after the word Closing.  That action creates an Obsidian file. 
    3) Next, go to the Account Template. Do that by clicking on the link which says Account Template with a blue line under it located in Part 7.
    4) Then copy all the information in the template starting on the line below Template.  A description on how to copy and paste is below.
    5) Click START HERE, click Part 7, click  USA Bank Checking. Then, paste which will add the template that you copied in step 4 above.