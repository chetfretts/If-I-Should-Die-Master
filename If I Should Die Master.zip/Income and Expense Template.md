#Template
## Income
**Income** for which the estate may receive:

**Income Source/Date Rec'd/(Period: Monthly-Quarterly-Yearly)=Amount
How Received**

(**List the income data from all sources**)

## Expenses
**Expenses** for which the estate may be liable - credit cards, mortgages, condo fees, HOA fees, taxes, utilities:

**Expense Source/Date Due/(Period: Monthly-Quarterly-Yearly) = Amount
How Paid**

(**List the expense data due to all sources**)