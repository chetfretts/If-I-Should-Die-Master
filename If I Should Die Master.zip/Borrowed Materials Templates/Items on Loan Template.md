#Template 
Item: (**Item**)
Location: (**Location**)
(Don't forget chargers, carrying cases, and other auxiliary devices)
On loan from: (**Name or Company**)
Contact: (Customer Service):  (**Contact**)
Contact Address: (**Address**)
Contact Phone:  (**Phone**)
Contact Email:  (**email**)
Additional Pertinent Information:
    (**Enter the information**)
