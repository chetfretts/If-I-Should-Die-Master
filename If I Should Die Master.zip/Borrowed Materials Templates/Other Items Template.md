#Template 
**Personal Loans:**
    Amount: (**Amount**)
    Lender:  (**Name**)
        (**Address**)
        (**Phone**)
        (**email**)

**Art works, furniture, etc.:**
    Item: (**Item**)
    Location: (**Location**)
    Owner: (**Name**)
        (**Address**)
        (**Phone**)
        (**email**)
