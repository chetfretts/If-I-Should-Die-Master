#Template 
**Loaned to Otherss:**
    Item: (**Item**)
    Loaned To:  (**Name**)
        (**Address**)
        (**Phone**)
        (**email**)
    Condition of Loan:
        (**Explain the condition of the loan**)

