#ToAddData 
# Part 13 Business Relationships
There are many kinds of business.  Some have documents and some do not.  These business  relationships should be documented.  

The following template provides a lot of information that helps document each business relationship:

[[Business Relationship Template]]

(**Using the Business Relationship Template as a template, add a new file for each business relationship**)

