#ToAddData 
# Part 6 Insurance
## Life Insurance
[[Life Insurance Template]]
(**Using  Life Insurance Template as a template, add a new file for each life insurance policy**)

## Vehicle
[[Vehicle Template]]
(**Using  Vehicle Template as a template, add a new file for each vehicle policy**)

## Boats or Trailers
[[Boat or Trailer Template]]
(**Using  Boat or Trailer Template as a template, add a new file for each boat or trailer policy**)

## Other Vehicles
[[Other Vehicle Template]]
(**Using  Other Vehicle Template as a template, add a new file for each other vehicle policy**)

## Homeowners or Renters
[[Homeowner or Renters Template]]
(**Using  Homeowners or Renters Template as a template, add a new file for each homeowners or renters policy**)

## Flood or Hurricane or Earthquake
[[Flood or Hurricane or Earthquake Template]]
(**Using Flood or Hurricane or Earthquake Template as a template, add a new file for each flood, hurricane, or earthquake policy**)

## Business Insurance (Crop, Loss of Profits, Business, Liability, Malpractice, etc.)
[[Business Insurance Template]]
(**Using  Business Insurance Template as a template, add a new file for each different business insurance policy**)




