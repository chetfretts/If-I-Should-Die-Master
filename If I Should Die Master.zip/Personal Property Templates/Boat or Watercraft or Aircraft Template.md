#Template 
# Boat or Craft
Type of Boat or Craft:  (**Type**)
State:  (**State**)
Make:  (**Make**)
Model:  (**Model**)
Year: (**Enter Year**)
Titled To: (**Name and Address**)
Title Number (**Title Number**)
Title Location (**Title Location**)
If there is a loan, list creditor's (**Creditor's Name and Address**)
