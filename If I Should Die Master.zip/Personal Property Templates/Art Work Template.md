#Template 
# Art 
Include a descripting of each piece of art and it's location:
    (**List each piece description and it's location**)

Note: It may be best to photograph each piece and make accompanying notes.

