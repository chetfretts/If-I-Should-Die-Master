#Template 
# Furniture and Other Items
This category may include items such as furniture, books, photos, dishes, silverware, crystal, gold, silver, coins, etc.

Include a descripting of each piece of furniture or other item and it's location:
    (**List each piece description and it's location**)

Note: It may be best to photograph each piece and make accompanying notes.

