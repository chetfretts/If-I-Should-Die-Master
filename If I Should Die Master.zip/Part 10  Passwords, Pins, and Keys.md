#ToAddData 
# Part 10 Passwords, Pins, User IDs, and Keys
## Introduction
The following information will detail where to locate the passwords, pins, and keys so that the executor or person in charge can find them.
**(Note: It best not to list passwords in this chapter.  Detail them in a separate list that is held in a secure location. This text file is not secure or encrypted)**

## Passwords, Pins, User IDs
My password, pin, user ID list is located at:  
    (**Add information if applicable**) 

Computer passwords and codes (It's best not to list passwords here.  This text file is not secure or encrypted)
    (**Add information if applicable**) 

Bank Pins or User IDs (All accounts)
    (**Add information if applicable**) 

Financial accounts:
    **Bank Account        Account       User ID, Password, Pin** (It's best not to list passwords here.  This text file is not secure or encrypted)
    (**Add information if applicable**)     

Cell Phone Pin or entry codes
    (**Add information if applicable**) 

Social Network Accounts (User ID and Passwords)
    (**Add information if applicable**) 

Automobile Security Systems
    (**Add information if applicable**) 

Do you have a "default" password and or personal ID code or number
    (**Add information if applicable**) 

Door Lock entry codes and its master code (for changes)
    (**Add information if applicable**) 

## Keys
Take a few minutes and tag every key and place the keys in a known location.

Where are the keys located?
    (**Add information if applicable**) 

Beginning with the largest key on a key ring with teeth facing out or to the left in your key ring, list what they will open:
    1. First key
    2. Second key
    3. Third key
    4. etc.
    (**Add information if applicable**) 

Where are your car keys located (include boats, RVs. etc.)?
    1. First vehicle  (Vehicle Year, Make, Model   Key Location)
    2. Second vehicle  (Vehicle Year, Make, Model   Key Location)
    3. Third vehicle  (Vehicle Year, Make, Model   Key Location)
    4. etc.
    (**Add information if applicable**)

Where do you keep extra keys, neighbor's keys, shed or storage locker keys?
    (**Add information if applicable**) 

Who has copies of what keys (Neighbors, cleaning people, care givers, workman)
   **Name    Phone    Key to?    Relationship**
   (**Add information if applicable**)

Where is the key to your safe deposit box?
    (**Add information if applicable for each box**)
    
If you live in a gated or otherwise secure environment such as a condo, who do your heirs contact to secure entry?  Where do they park?
    (**Add information if applicable**)



