#ToAddData 
# Part 8 Real Property
## Introduction
Real property relates to land and improvements to land.  Business relationships may involve real property (see Parts 9 and 13).

## Undeveloped Real Property(acreage, buildings, lots, farms, burial plots, etc.)
[[Undeveloped Parcel Template]]
(**Using Undeveloped Parcel Template as a template, add a new file for each undeveloped  parcel**)



## Developed (houses, condos, apartments, buildings, time shares, garages, etc.)
[[Developed Parcel Template]]
(**Using Developed Parcel Template as a template, add a new file for each developed parcel**)
