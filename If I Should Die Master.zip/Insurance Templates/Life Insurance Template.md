#Template 
# Life Insurance
Insured:
    Amount:
    Carrier:
    Agent:
    Notify:
    Type of Coverage:
    Location of policy: